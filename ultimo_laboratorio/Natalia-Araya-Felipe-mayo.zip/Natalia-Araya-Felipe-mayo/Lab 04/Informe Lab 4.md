![Logo UCN](images/60x60-ucn-negro.png)
# Laboratorio 04: Cálculo de frecuencia peatonal 


## 1. Introducción
<div style="text-align: justify;">
Tomando en consideración un contexto del ancho de las puertas de entrada y salida, se requiere una exploración del flujo de individuos a lo largo de pasillos y áreas de acceso unidireccional. El objetivo primordial es evaluar la dimensión de las entradas y salidas en un espacio determinado. Para tal fin, se propone la utilización de dos archivos de texto en formato .txt, que contienen registros que se encuentran expresados en coordenadas métricas, permitiendo una medición precisa en relación con la disposición física del área bajo análisis.


### 1.1 Justificación 

Comprender el flujo de personas en puntos críticos como por ejemplo en las puertas del metro ya que es crucial para la gestión del transporte urbano. El análisis de coordenadas de tránsito peatonal proporciona información precisa para tomar decisiones informadas en la asignación de recursos y en la mejora de la infraestructura, optimizando la eficiencia del sistema y enriqueciendo la experiencia de los usuarios.

### 1.3 Objetivos
### Objetivo General
Obtener el promedio de distancias de una peaton es especifico con sus peatones vecinos (SK).

### Objetivos específicos 

1. Analizar el comportamiento de los peatones en base a sus velocidades promedio y SK.
2. Realizar un histograma con el fin de observar los resultados obtenidos.
3. Realizar un grafico de disperción con respecto a los SK y las velocidades obtenidas. 

## 2. Marco teórico
**IPython:** Una potente interfaz interactiva para Python enriquece la experiencia de programación al proporcionar un entorno interactivo.

**Visual Studio:** Es un entorno de desarrollo integrado potente y multifuncional que se utiliza en el presente laboratorio. Visual brinda herramientas avanzadas para la creación, depuración y despliegue de aplicaciones. 

**NumPy:** Una librería fundamental en Python que se utiliza para cálculos numéricos y manipulación de matrices multidimensionales.

**Matplotlib:** Esta librería se usará para la visualización de datos y la creación de gráficos. Su integración con NumPy lo convierte en una herramienta poderosa para crear visualizaciones en el análisis de datos.

**Pandas:** Es una librería de Python para análisis de datos. Ofrece estructuras flexibles como Series y Data Frames, facilitando la carga, limpieza y manipulación eficiente de datos.

**Time:** Es utilizada para medir el tiempo de ejecución del código.

**Psutil:** Se utiliza para obtener información del sistema, como la memoria utilizada.

**Scipy Spatial** Submódulo de Scipy utilizado para trabajar con problemas de geometría y datos espaciales.

## 3. Materiales y métodos
Los elementos para utilizar en el presente laboratorio corresponden principalmente a las coordenadas (X, Y,  Z) en metros como unidad de medida extraídas del conjunto de datos llamado "UNI_CORR_500_01.txt", estas coordenadas representan las unidades tridimensionales por las que las personas han pasado. Cada registro tiene información sobre las coordenadas X, Y, Z de la posición de una persona en un momento específico. Cabe recalcar que dentro del conjunto de datos existe el id de la persona que realiza la observación de las coordenadas a través de una cámara y el número de frame correspondiente. El archivo 01 contiene más de veinticinco mil datos.

Específicamente, el experimento busca procesar las coordenadas capturadas por una cámara en cada uno de los frame para calcular las distancias y el tiempo con el fin de obtener la velocidad a la que transita cada peatón y sus respectivos SK para analizar sus comportamientos en un entorno monitoreado. Es importante destacar que los resultados ofrecen valiosa información que apoyan la toma de correctas decisiones para mejorar la eficiencia de la asignación de recursos y diseño de espacios, entre otros. 

Para realizar el análisis correcto de la base de datos y obtener los resultados esperados fue necesario realizar los siguientes pasos por medio de Visual Studio Code con la ayuda del lenguaje Python. 

1- Importa las bibliotecas necesarias: numpy, pandas, time, psutil, scipy.spatial.KDTree y matplotlib.pyplot.

2- Lee un archivo de datos en formato CSV llamado "UNI_CORR_500_01.txt" y almacena los datos en un DataFrame.

3- Define se define una función para calcular la distancia, el tiempo y la velocidad de cada frame.

4- Se calcula la velocidad promedio de cada grupo.

5- Agrega una nueva columna llamada "sk" con valores iniciales 0 al DataFrame data_frame.

6- Itera a través de los valores únicos de la columna "Frame" en data_frame y se designa un peatón específico para comparar con sus peatones vecinos en un radio de 3 metros a través de sus coordenadas.

7- Se calcula la variable "sk" con respecto a la diferencia entre los X e Y, su raíz, sumatoria y división por el total de peatones vecinos. Estos valores son agregados en el Data Frame.

8- Se crea un histograma de las velocidades promedio utilizando matplotlib junto a un gráfico de dispersión ("sk" vs. velocidad real) utilizando matplotlib y se sube a la web.

## 4. Resultados obtenidos
En la tabla 1 se pueden observar los resultados obtenidos con respecto al Código utilizado en este laboratorio el cual cuenta con funciones de la librería pandas, funciones para calcular la velocidad de las personas y el cálculo del sk.

|       Experimento        | Tiempo de ejecución (mseg) |  Memoria utilizada (Mb) | 
|--------------------------|----------------------------|-------------------------|
| Laboratorio (p01.py)     |      12842.640 mseg        |        11.746 Mb        |

<Center>
  <figcaption>Tabla 1: Medidas de desempeño </figcaption>
</Center>

A continuación, en la tabla 2 se presentan las métricas obtenidas con respecto a la velocidad del peatón y al SK calculado. 

El análisis de los datos revela que los peatones tienen una velocidad promedio de aproximadamente 1.47 metros por segundo, con una variabilidad entre velocidades máximas de 2.49 metros por segundo y mínimas de 0.92 metros por segundo. La variable "sk", que mide las distancias promedio entre peatones vecinos, tiene un valor promedio de 1.90 metros y oscila entre un mínimo de 0 metros en ciertos casos y un máximo de casi 3 metros. Esto sugiere que, en general, los peatones mantienen una distancia promedio de alrededor de 1.90 metros entre sí. Las estadísticas de varianza en velocidad y "sk" reflejan la dispersión y variabilidad en estos valores respectivamente. 


|       Tipo         |       Velocidad Peatón      |           SK           | 
|--------------------|-----------------------------|------------------------|
|  Promedio          |        1.4742 mt/seg        |      1.901 metros      |
|  Máximo            |        2.4883 mt/seg        |      2.999 metros      |
|  Mínimo            |        0.9167 mt/seg        |      0.000 metros      |
|  Varianza          |        0.0488 mt/seg        |      0.117 metros      |
<Center>
  <figcaption>Tabla 2: Métricas del experimento</figcaption>
</Center>

En la ilustración 01 se encuentran las distintas velocidades de cada uno de los peatones del archivo TXT "UNI_CORR_500_01" presentadas por un histograma, cada una se las velocidades están en el eje horizontal y la cantidad de personas que siguen las distintas velocidades están en el eje vertical. La mayoría de los peatones siguen velocidades entre 1.3 y 1.7 metros por segundo.

<center>
<figure>
  <img src="images/Histograma_01.png" alt="Mapa de calor" width="300">
  <figcaption>Ilustración 1: Histograma de velocidades observación 01</figcaption>
</figure>
</center>

En la ilustración 2 se muestran los resultados obtenidos con respecto al índice SK representados en un gráfico de dispersión.

El scatter plot que representa la velocidad real de los peatones en función de la variable "sk" brinda una perspectiva interesante sobre la relación entre la distancia promedio entre peatones vecinos y sus velocidades. La distribución horizontal de los puntos sugiere una tendencia de velocidades similares para diferentes valores de "sk". Sin embargo, la concentración de puntos en el centro del gráfico, con menos puntos en las esquinas, sugiere que hay una densidad más alta de observaciones en cierto rango de distancias entre peatones. Esto podría indicar que en esa región, la relación entre "sk" y la velocidad real es más consistente, mientras que en las regiones extremas, podría haber mayor variabilidad en las velocidades para valores de "sk" similares. Por último es importante destacar que hay puntos que se desvían significativamente de la línea recta, podrían ser valores atípicos que afectan la distribución general


<center>
<figure>
  <img src="images/sk.png" alt="Mapa de calor" width="300">
  <figcaption>Ilustración 2: Gráfico de dispersión SK</figcaption>
</figure>
</center>

Al analizar los valores encontrados en el gráfico de dispersión es pertinente concluir que los peatones con un SK entre 1.5 y 2.5 metros siguen velocidades entre 1 y dos metros por segundo.

Corroborando lo anterior: 
Al examinar detenidamente la Ilustración 3, obtenida del video que muestra el flujo de personas a lo largo de un corredor con una entrada en B1 de 1,00 metro y una salida en B2 de 5,00 metros, es posible deducir que el flujo de personas es rápido y de baja densidad debido a las medidas de entrada lo cual explicaría la distancia promedio SK entre peatones. Además, es importante destacar que al inicio del pasillo las personas se separan debido a la presencia de un obstáculo en esa área. Cabe mencionar que, en este flujo, se registra la entrada de 148 personas en el cual ninguno se detiene durante el tránsito, solo varía la velocidad debido a las personas más cercanas.
<center>
<figure>
  <img src="images/Personas-pasillo.png" alt="Mapa de calor" width="300">
  <figcaption>Ilustración 3: Transeúntes 01</figcaption>
</figure>
</center>

**Página web**

En la página web utiliza la biblioteca Streamlit y Python para mostrar visualizaciones interactivas basadas en datos de seguimiento de personas en un pasillo. Los datos se cargan desde dos bases de datos diferentes que puedes seleccionar mediante botones en la barra lateral. La página presenta gráficos de dispersión, histogramas de coordenadas y velocidades, así como un mapa de calor para analizar el comportamiento de las personas en el pasillo. Puedes personalizar el número de bins en los histogramas utilizando un slider en la barra lateral para explorar los datos de manera más detallada. (Link de la página: https://ultimolab-natalia-araya-felipe-mayo.streamlit.app/ )

## 5. Conclusiones
El análisis detallado de las dimensiones de las puertas en un pasillo unidireccional revela una conexión intrínseca entre la eficiencia del flujo de personas y el diseño espacial, en este caso, una entrada de 1 metro y una salida de 5 metros influye directamente en la velocidad y flujo de peatones, además, influye en la distancia en la que estos se encuentran unos de otros. 

La presencia de una forma de campana de Gauss en el histograma de velocidades y frecuencia de peatones sugiere que las velocidades están distribuidas simétricamente alrededor de un valor central, indicando una probabilidad similar de velocidades por encima y por debajo de la velocidad promedio. La variabilidad en las velocidades se refleja en la amplitud de la campana. Esta distribución puede señalar un comportamiento natural en el movimiento humano, con la mayoría de los peatones cerca del valor promedio y menos individuos a velocidades extremas. 

Los resultados obtenidos en el gráfico de dispersión concuerdan con el histograma, además, evidencian el patrón que siguen las personas y la relación entre sus velocidades y su distancia correspondiente, además se lograron identificar valores atípicos en la observación. 

Finalmente es evidente que se logró el objetivo específico al lograr obtener el SK, por otro lado se analizó el comportamiento de los peatones en base a sus velocidades y sus respectivos SK realizando un histograma y un gráfico de dispersión junto a las métricas correspondientes de los datos. 
</div>
