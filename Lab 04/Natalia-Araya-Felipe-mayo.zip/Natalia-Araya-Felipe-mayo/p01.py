import numpy as np
import pandas as pd
import time
import psutil
from scipy.spatial import KDTree
import matplotlib.pyplot as plt

inicio_memoria = psutil.virtual_memory().used
tiempo_inicio = time.time()

data_frame = pd.read_csv("UNI_CORR_500_01.txt", delimiter="\t", header=0, skiprows=3)
data2 = pd.read_csv("UNI_CORR_500_08.txt", delimiter="\t", header=0, skiprows=3)

def calcular_velocidad_grupo(grupo):
    grupo["Distancia"] = np.sqrt(grupo["X"].diff(periods=-1)**2 + grupo["Y"].diff(periods=-1)**2)
    grupo["tiempo"] = 1 / 25
    grupo["Velocidad"] = grupo["Distancia"] / grupo["tiempo"]
    return grupo

def calcular_sk(df):
    df["sk"] = 0
    for i in df["Frame"].unique():
        df_frame = df[df["Frame"] == i].copy()
        coordenadas = df_frame[["X", "Y"]].values
        df_frame["indices"] = np.arange(len(df_frame))
        for id in df_frame["indices"]:
            punto = coordenadas[id]
            radius = 3
            tree = KDTree(coordenadas)
            vecino_indices = tree.query_ball_point(punto, radius)
            vecino_indices = [index for index in vecino_indices if index != id]
            vecino_coordenadas = coordenadas[vecino_indices]
            cantidad_vecinos = len(vecino_indices)
            if cantidad_vecinos > 0:
                diferencia = np.sqrt(np.sum((vecino_coordenadas - punto)**2, axis=1))
                promedio_sk = np.sum(diferencia) / cantidad_vecinos
            else:
                promedio_sk = 0
            indices_filtrados = df_frame.index[df_frame["indices"] == id].values
            df.at[int(indices_filtrados), "sk"] = promedio_sk
    return df

grupos_01 = data_frame.groupby("# PersID", group_keys=False)
df_velocidad_01 = grupos_01.apply(calcular_velocidad_grupo)
Velocidad_prom_01 = df_velocidad_01.groupby("# PersID")["Velocidad"].agg(np.mean)
data_frame = calcular_sk(data_frame)

grupos_08 = data2.groupby("# PersID", group_keys=False)
df_velocidad_08 = grupos_08.apply(calcular_velocidad_grupo)
Velocidad_prom_08 = df_velocidad_08.groupby("# PersID")["Velocidad"].agg(np.mean)
data2 = calcular_sk(data2)

print("Velocidad promedio de todas las personas (data_frame):", Velocidad_prom_01.mean())
print("Velocidad Maxima (data_frame):", Velocidad_prom_01.max())
print("Velocidad Minima (data_frame):", Velocidad_prom_01.min())
print("Velocidad Varianza (data_frame):", Velocidad_prom_01.var())

print("SK promedio de todas las personas (data_frame):", data_frame["sk"].mean())
print("SK Maxima (data_frame):", data_frame["sk"].max())
print("SK Minima (data_frame):", data_frame["sk"].min())
print("SK Varianza (data_frame):", data_frame["sk"].var())

print("------------------------------------------------------------------------")

print("Velocidad promedio de todas las personas (data2):", Velocidad_prom_08.mean())
print("Velocidad Maxima (data2):", Velocidad_prom_08.max())
print("Velocidad Minima (data2):", Velocidad_prom_08.min())
print("Velocidad Varianza (data2):", Velocidad_prom_08.var())

print("SK promedio de todas las personas (data2):", data2["sk"].mean())
print("SK Maxima (data2):", data2["sk"].max())
print("SK Minima (data2):", data2["sk"].min())
print("SK Varianza (data2):", data2["sk"].var())

print("------------------------------------------------------------------------")

fin_tiempo = time.time()
tiempo_transcurrido = fin_tiempo - tiempo_inicio
fin_memoria = psutil.virtual_memory().used
memoria_utilizada = (fin_memoria - inicio_memoria) / 1048576
print(f"Tiempo de ejecución: {tiempo_transcurrido * 1000} milisegundos")
print(f"Memoria utilizada: {memoria_utilizada} Mega bytes")

fig, ax = plt.subplots()
histograma = ax.hist(Velocidad_prom_01, bins=20, edgecolor='black', alpha=0.7, color='Purple')
plt.title("Histograma de Velocidades datos 01")
plt.xlabel("Velocidades")
plt.ylabel("Frecuencia de personas")
plt.grid(True, linestyle='--', alpha=0.7)

fig, ax = plt.subplots()
histograma = ax.hist(Velocidad_prom_08, bins=20, edgecolor='black', alpha=0.7, color='Orange')
plt.title("Histograma de Velocidades datos 08")
plt.xlabel("Velocidades")
plt.ylabel("Frecuencia de personas")
plt.grid(True, linestyle='--', alpha=0.7)

plt.figure(figsize=(10, 6))
plt.scatter(data_frame["sk"], df_velocidad_01["Velocidad"], label="Observación 01", color='Purple')
plt.scatter(data2["sk"], df_velocidad_08["Velocidad"], label="Observación 08", color='Orange')

plt.xlabel("sk")
plt.ylabel("Velocidad real")
plt.title("sk vs. Velocidad real")
plt.grid()
plt.legend()

# Ajustar el rango del eje y
plt.ylim(0, 7)

plt.show()