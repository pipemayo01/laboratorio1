Carpeta para guardar imágenes y gráficos utilizados en el documento.
